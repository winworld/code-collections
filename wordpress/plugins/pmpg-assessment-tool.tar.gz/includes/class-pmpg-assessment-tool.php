<?php

/**
 * Class PMPg_Assessment_Tool Integration
 */



class PMPg_Assessment_Tool {	
	
	const API_URL									 = "https://hub.pm-partners.com.au/apex/hub";
	const CLIENT_ID					       = 'S9ld-bxlFOZRk3ra0heobw..';
	const CLIENT_SECRET						 = 'V5YP5ew-OaIg-8Yeb03E0w..';		
	
	private $TOKEN_KEY;

	public function __construct() {

	}
	
	private function make_request( string $url_path, string $method = 'GET', $headers = [], $post_data = [] ) {
		
		$assessment_url = self::API_URL . $url_path;
		// Create a Request with WordPress
		$response = wp_remote_request( $assessment_url, [
			'method'  => $method,
			'headers' => [
				'grant_type' => 'client_credentials',
				'client_id' => self::CLIENT_ID, 
				'client_secret' => self::CLIENT_SECRET,
				'Content-Type' => 'application/json',
			],
			'body'    => 'POST' === $method ? json_encode( $post_data ) : $post_data
		] );
		
	
		// Check the Result Here
		$response_code = wp_remote_retrieve_response_code( $response );
		// Otherwise, lets proceed with the Normal Data
		$response_body = json_decode( wp_remote_retrieve_body( $response ) );
	
		// Possible Error Here
		if ( $response_code >= 400 ) {
			return new WP_Error( $response_code, wp_remote_retrieve_response_message( $response ), $response_body );
		}

		return [ 'http_code' => $response_code, 'result' => $response_body ];
	}
	
	public function get_data() {
		$curl = curl_init();

		curl_setopt_array($curl, array(
			CURLOPT_URL => 'https://hub.pm-partners.com.au/apex/hub/projectrisk/get_risk/1/tanya@pm-partners.com',
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_ENCODING => '',
			CURLOPT_MAXREDIRS => 10,
			CURLOPT_TIMEOUT => 0,
			CURLOPT_FOLLOWLOCATION => true,
			CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			CURLOPT_CUSTOMREQUEST => 'GET',
			CURLOPT_HTTPHEADER => array(
				'Content-Type: application/json',
				'Authorization: Bearer 5CS3Fto92PaRPKNSjNpYlQ'
			),
		));

		$response = curl_exec($curl);

		curl_close($curl);
		echo $response;
	}
	
	public function get_token() {
		$path = '/oauth/token';
		$token_url = self::API_URL . $path;
		
		$authorization = base64_encode(self::CLIENT_ID . ":" . self::CLIENT_SECRET);
		$curl = curl_init();

		$params = array(
			CURLOPT_URL =>  $token_url,											
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_SSL_VERIFYHOST =>false,
  		CURLOPT_SSL_VERIFYPEER => false,
			CURLOPT_ENCODING => '',
			CURLOPT_MAXREDIRS => 10,
			CURLOPT_TIMEOUT => 0,
			CURLOPT_FOLLOWLOCATION => true,
			CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			CURLOPT_CUSTOMREQUEST => 'POST',			 
			CURLOPT_POSTFIELDS => "grant_type=client_credentials",
			CURLOPT_HTTPHEADER => array(		
				"Authorization: Basic {$authorization}",
				"content-type: application/x-www-form-urlencoded",							
			),
		);			

		curl_setopt_array($curl, $params);

		$response = curl_exec($curl);		
	
		$err = curl_error($curl);

		curl_close($curl);
		
	

		if ($err) {
			return null;
		} else {
			$response = json_decode($response);    
			return $response;			
		}
		
		return null;
				
	}
	
	public function get_oauth_token() {
		
		$path = '/oauth/token';
		$post_data = [
			'client_id' 		=> self::CLIENT_ID,
			'client_secret'	=> self::CLIENT_SECRET,
		];
		
		$response = self::make_request( $path, 'POST', NULL );
// 		var_dump( $response );
// 		die;
		if ( $response instanceof WP_Error ) {			
			//throw new Exception( 'you don' );
			return;
		}
		
		var_dump( $response );
	}

}
