<?php
/*
Plugin Name: PM-Partners group - Complexity Assessment Tool
Plugin URI: https://pm-partners.com.au
Description: This tool calculates the project results based on the user's input
Version: 1.0
Author: PM-Partners group
Author URI: https://pm-partners.com.au
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

define("DOMPDF_UNICODE_ENABLED", true);

if (!defined('PMPG_ASSESSMENT_TOOL_PLUGIN')) {
	
	define('PMPG_ASSESSMENT_TOOL_PLUGIN', __FILE__);
	define('PMPG_ASSESSMENT_TOOL_PLUGIN_BASENAME', plugin_basename(PMPG_ASSESSMENT_TOOL_PLUGIN));
	define('PMPG_ASSESSMENT_TOOL_PLUGIN_DIR', untrailingslashit(dirname(PMPG_ASSESSMENT_TOOL_PLUGIN)));  
}

require plugin_dir_path( __FILE__ ) . 'includes/class-pmpg-assessment-tool.php';

function run_pmpg_assessment_tool() {
	if( isset( $_POST['_pmpg_tool'] ) ) {
		$pmpg_tool = new PMPg_Assessment_Tool();	
		$response = $pmpg_tool->get_token();		
		if( $response !== null ) {
			$pmpg_tool->$TOKEN_KEY	= $response->access_token;
		}
		echo $pmpg_tool->$TOKEN_KEY;
		var_dump($_POST);
		die;
	}
}

run_pmpg_assessment_tool();
